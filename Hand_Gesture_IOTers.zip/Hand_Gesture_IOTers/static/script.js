// Fungsi untuk menerima data gerakan tangan dari backend
var eventSource = new EventSource('/stream');

// Mengatur posisi kursor berdasarkan data x, y dari server
eventSource.onmessage = function(event) {
  var data = JSON.parse(event.data);
  var cursor = document.getElementById('cursor');

  // Ubah posisi kursor
  cursor.style.left = `${data.x * window.innerWidth}px`;
  cursor.style.top = `${data.y * window.innerHeight}px`;
};
