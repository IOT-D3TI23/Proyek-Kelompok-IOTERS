from flask import Flask, render_template, Response
import cv2
import mediapipe as mp
import mysql.connector
import json
import math

app = Flask(__name__)

# Koneksi ke MySQL
db = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="",
    database="besok",
    connection_timeout=600  # Timeout diperpanjang jadi 10 menit
)
cursor = db.cursor()

# Inisialisasi MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils

# Fungsi untuk mendeteksi klik virtual
def detect_click(landmarks):
    thumb_tip = landmarks.landmark[4]  # Thumb tip
    index_tip = landmarks.landmark[8]  # Index finger tip

    # Hitung jarak antara ibu jari dan telunjuk
    distance = math.sqrt((thumb_tip.x - index_tip.x) ** 2 + (thumb_tip.y - index_tip.y) ** 2)

    return distance < 0.05  # Klik jika jarak sangat dekat

# Fungsi untuk menangkap frame video dan mendeteksi tangan
def generate_frames():
    cap = cv2.VideoCapture(0)  
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb_frame)
        
        action_data = {"action": None, "x": 0, "y": 0}  # Inisialisasi default
        
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                x = hand_landmarks.landmark[8].x
                y = hand_landmarks.landmark[8].y
                action_data = {"action": "move", "x": x, "y": y}

                # Deteksi klik
                if detect_click(hand_landmarks):
                    action_data = {"action": "click", "x": x, "y": y}

                # Menyimpan ke database dengan pengecekan koneksi
                try:
                    if not db.is_connected():
                        db.reconnect()
                    cursor.execute("INSERT INTO gesture_data (x, y) VALUES (%s, %s)", (x, y))
                    db.commit()
                except mysql.connector.Error as err:
                    print(f"Database error: {err}")

                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
        
        yield f"data: {json.dumps(action_data)}\n\n"
        
        cv2.imshow('Hand Tracking', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/stream')
def stream():
    return Response(generate_frames(), content_type='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True)
